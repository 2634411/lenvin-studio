<?php

use App\Http\Controllers\DemoProfileController;
use Illuminate\Support\Facades\Route;

Route::get('/', [DemoProfileController::class, 'show'])->name('demo.profile');
Route::post('/profile', [DemoProfileController::class, 'save'])->middleware('throttle:60,1')->name('demo.save');
