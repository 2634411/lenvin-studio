<?php

namespace Database\Factories;

use App\Models\DemoProfile;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<DemoProfile>
 */
class DemoProfileFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            //
        ];
    }
}
