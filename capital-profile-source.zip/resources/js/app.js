import { createApp, h } from 'vue';
import { createInertiaApp } from '@inertiajs/vue3';
import Profile from './Pages/Profile.vue';
import '../css/app.css';
const staticRoot = document.querySelector('[data-static-demo]');
if (staticRoot) {
 const seed={name:'Анна Иванова',email:'demo@example.com',phone:'',city:'Казань',birth_date:'1990-05-20',messengers:['MAX'],family:'',children:'',employment:'',profession:'',risk:'',horizon:'',goal_period:'1 год',main_goal:'Создать пассивный доход',goals:[{id:2,amount:300000}],situation:'Учебный пример: хочу создать резервный фонд и постепенно закрыть кредит.',strategy:'',active_until:60};
 let profile=seed; try { profile=JSON.parse(localStorage.getItem('capital-profile-preview-v1')) || seed; } catch {}
 createApp(Profile,{profile,preview:true,saved:false,savedAt:''}).mount(staticRoot);
} else createInertiaApp({ resolve: () => Profile, setup({ el, App, props, plugin }) { createApp({ render: () => h(App, props) }).use(plugin).mount(el); } });