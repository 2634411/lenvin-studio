<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/** Изолированный учебный профиль. Не содержит учетной записи или пароля. */
class DemoProfile extends Model
{
    use HasFactory;

    protected $fillable = ['session_key', 'data'];

    /** Приводит JSON анкеты к массиву, независимо от будущей схемы платформы. */
    protected function casts(): array
    {
        return ['data' => 'array'];
    }
}
