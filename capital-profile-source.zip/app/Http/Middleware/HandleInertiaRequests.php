<?php

namespace App\Http\Middleware;

use Inertia\Middleware;

/** Подключает серверные страницы Inertia к компонентам Vue. */
class HandleInertiaRequests extends Middleware
{
    protected $rootView = 'app';
}
