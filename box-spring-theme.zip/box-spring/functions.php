<?php
if (!defined('ABSPATH')) { exit; }
add_action('after_setup_theme', function () {
    add_theme_support('editor-styles');
    add_editor_style('style.css');
    add_theme_support('title-tag');
    add_theme_support('responsive-embeds');
});
add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('box-spring', get_stylesheet_uri(), array(), wp_get_theme()->get('Version'));
});
add_action('admin_menu', function () {
    add_theme_page('Настройка Box Spring', 'Настройка Box Spring', 'manage_options', 'box-spring-setup', 'box_spring_setup_page');
});
function box_spring_setup_page() {
    if (!current_user_can('manage_options')) { return; }
    if (isset($_POST['box_spring_create'])) {
        check_admin_referer('box_spring_create');
        $page_id = absint(get_option('box_spring_home_page'));
        if (!$page_id || !get_post($page_id)) {
            $content = file_get_contents(get_theme_file_path('/content.html'));
            $content = str_replace('__ASSET__', esc_url(get_theme_file_uri('/assets')), $content);
            $page_id = wp_insert_post(array('post_type'=>'page', 'post_status'=>'draft', 'post_title'=>'Кровати Box Spring для отелей', 'post_content'=>wp_slash($content)), true);
            if (is_wp_error($page_id)) { echo '<p>Не удалось создать страницу.</p>'; return; }
            update_option('box_spring_home_page', $page_id);
        }
        echo '<p>Черновик готов. <a href="'.esc_url(get_edit_post_link($page_id)).'">Открыть страницу в редакторе</a></p>';
    }
    echo '<div class="wrap"><h1>Настройка Box Spring</h1><p>Создайте черновик главной страницы из редактируемых блоков. Существующие страницы не изменяются. Проверьте материалы, опубликуйте страницу и выберите ее в Настройки → Чтение → Главная страница.</p><form method="post">';
    wp_nonce_field('box_spring_create');
    echo '<button class="button button-primary" name="box_spring_create" value="1">Создать или открыть черновик</button></form><p>Для редактирования: Страницы → Кровати Box Spring для отелей. Чтобы добавить модель, выделите группу карточки в списке блоков и выберите «Дублировать». Затем замените фото и текст.</p></div>';
}
