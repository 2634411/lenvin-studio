<?php
if (!defined('ABSPATH')) { exit; }
add_action('after_setup_theme', function () {
    add_theme_support('editor-styles');
    add_editor_style('style.css');
    add_theme_support('title-tag');
    add_theme_support('responsive-embeds');
});
add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('box-spring', get_stylesheet_uri(), array(), wp_get_theme()->get('Version'));
});
add_action('admin_menu', function () {
    add_theme_page('Настройка Box Spring', 'Настройка Box Spring', 'manage_options', 'box-spring-setup', 'box_spring_setup_page');
});
function box_spring_setup_page() {
    if (!current_user_can('manage_options')) { return; }
    if (isset($_POST['box_spring_create'])) {
        check_admin_referer('box_spring_create');
        $page_id = absint(get_option('box_spring_home_page'));
        if (!$page_id || !get_post($page_id)) {
            $content = file_get_contents(get_theme_file_path('/content.html'));
            $content = str_replace('__ASSET__', esc_url(get_theme_file_uri('/assets')), $content);
            $page_id = wp_insert_post(array('post_type'=>'page', 'post_status'=>'draft', 'post_title'=>'Кровати Box Spring для отелей', 'post_content'=>wp_slash($content)), true);
            if (is_wp_error($page_id)) { echo '<p>Не удалось создать страницу.</p>'; return; }
            update_option('box_spring_home_page', $page_id);
        }
        echo '<p>Черновик готов. <a href="'.esc_url(get_edit_post_link($page_id)).'">Открыть страницу в редакторе</a></p>';
    }
    echo '<div class="wrap"><h1>Настройка Box Spring</h1><p>Создайте черновик главной страницы из редактируемых блоков. Существующие страницы не изменяются. Проверьте материалы, опубликуйте страницу и выберите ее в Настройки → Чтение → Главная страница.</p><form method="post">';
    wp_nonce_field('box_spring_create');
    echo '<button class="button button-primary" name="box_spring_create" value="1">Создать или открыть черновик</button></form><p>Для редактирования: Страницы → Кровати Box Spring для отелей. Чтобы добавить модель, выделите группу карточки в списке блоков и выберите «Дублировать». Затем замените фото и текст.</p></div>';
}

add_action('wp_enqueue_scripts', function () {
    wp_enqueue_script('box-spring-site', get_theme_file_uri('/assets/site.js'), array(), '1.1.0', true);
});
add_action('wp_head', function () {
    if (!is_front_page()) { return; }
    $description = 'Кровати Box Spring и мебель для гостиниц, апартаментов и баз отдыха. Производство в Петрозаводске, доставка и монтаж по Северо-Западу.';
    echo '<meta name="description" content="'.esc_attr($description).'">';
    echo '<meta property="og:type" content="website"><meta property="og:title" content="'.esc_attr(get_bloginfo('name')).'">';
    echo '<meta property="og:description" content="'.esc_attr($description).'"><meta property="og:url" content="'.esc_url(home_url('/')).'">';
    echo '<meta property="og:image" content="'.esc_url(get_theme_file_uri('/assets/hero-room.jpg')).'">';
});
add_action('admin_menu', function () {
    add_theme_page('Контакты Box Spring', 'Контакты Box Spring', 'manage_options', 'box-spring-contacts', 'box_spring_contacts_page');
});
function box_spring_contacts_page() {
    if (!current_user_can('manage_options')) { return; }
    if (isset($_POST['box_spring_save_contacts'])) {
        check_admin_referer('box_spring_contacts');
        $url = esc_url_raw(wp_unslash($_POST['max_url'] ?? ''));
        if ($url && (!in_array(strtolower(wp_parse_url($url, PHP_URL_HOST)), array('max.ru','www.max.ru','web.max.ru'), true) || wp_parse_url($url, PHP_URL_SCHEME) !== 'https')) { $url = ''; }
        update_option('box_spring_max_url', $url);
        update_option('box_spring_max_number', sanitize_text_field(wp_unslash($_POST['max_number'] ?? '+79062066875')));
        update_option('box_spring_inquiry_email', sanitize_email(wp_unslash($_POST['inquiry_email'] ?? '')));
        update_option('box_spring_privacy_url', esc_url_raw(wp_unslash($_POST['privacy_url'] ?? '')));
        echo '<div class="notice notice-success"><p>Контакты сохранены.</p></div>';
    }
    echo '<div class="wrap"><h1>Контакты Box Spring</h1><p>Номер и ссылка MAX меняются здесь и используются во всех кнопках. Форма появится после заполнения почты получателя и ссылки на согласованную политику обработки данных.</p><form method="post">';
    wp_nonce_field('box_spring_contacts');
    foreach (array('max_number'=>'Номер MAX','max_url'=>'Ссылка профиля MAX (https://max.ru/...)','inquiry_email'=>'Почта для заявок','privacy_url'=>'Ссылка на политику обработки данных') as $key=>$label) {
        $default = $key === 'max_number' ? '+79062066875' : '';
        echo '<p><label>'.esc_html($label).'<br><input class="regular-text" name="'.esc_attr($key).'" value="'.esc_attr(get_option('box_spring_'.$key, $default)).'"></label></p>';
    }
    echo '<button class="button button-primary" name="box_spring_save_contacts" value="1">Сохранить контакты</button></form></div>';
}
add_shortcode('box_spring_contact', function ($atts) {
    $atts = shortcode_atts(array('mode'=>'max'), $atts);
    $url = get_option('box_spring_max_url', '') ?: 'https://web.max.ru/';
    $number = get_option('box_spring_max_number', '+79062066875');
    if ($atts['mode'] === 'header') { return '<a href="'.esc_url($url).'">'.'Обсудить проект в MAX'.'</a>'; }
    if ($url && $url !== 'https://web.max.ru/') { return '<p><a href="'.esc_url($url).'">Обсудить проект в MAX →</a></p><p class="phone">'.esc_html($number).'</p>'; }
    return '<p><a href="https://web.max.ru/">Открыть MAX →</a></p><p>Найдите нас по номеру:</p><p class="phone">'.esc_html($number).'</p><button type="button" class="copy-max" data-copy-max="'.esc_attr($number).'" aria-live="polite">Скопировать номер для MAX</button>';
});
add_shortcode('box_spring_inquiry', function () {
    $email = get_option('box_spring_inquiry_email', '');
    $privacy = get_option('box_spring_privacy_url', '');
    if (!is_email($email) || !$privacy) { return ''; }
    $status = sanitize_key($_GET['inquiry'] ?? '');
    ob_start();
    if ($status === 'sent') { echo '<p class="form-status" role="status">Спасибо! Заявка отправлена.</p>'; }
    elseif ($status === 'error') { echo '<p class="form-status" role="alert">Заявку не удалось отправить. Пожалуйста, позвоните нам.</p>'; }
    echo '<form class="inquiry-form" method="post" action="'.esc_url(admin_url('admin-post.php')).'"><h3>Оставить заявку</h3><input type="hidden" name="action" value="box_spring_inquiry">';
    wp_nonce_field('box_spring_inquiry', 'inquiry_nonce');
    echo '<label>Как к вам обращаться<input name="inquiry_name" autocomplete="name" maxlength="120" required></label><label>Телефон<input name="inquiry_phone" type="tel" autocomplete="tel" maxlength="60" required></label><label>Расскажите о проекте<textarea name="inquiry_message" maxlength="4000" required></textarea></label><label class="trap" aria-hidden="true">Не заполняйте<input name="website" tabindex="-1" autocomplete="off"></label><label class="inquiry-consent"><input name="consent" type="checkbox" value="1" required><span>Согласен на обработку данных для ответа на заявку. <a href="'.esc_url($privacy).'">Политика обработки данных</a></span></label><button type="submit">Отправить заявку</button></form>';
    return ob_get_clean();
});
add_action('admin_post_box_spring_inquiry', 'box_spring_send_inquiry');
add_action('admin_post_nopriv_box_spring_inquiry', 'box_spring_send_inquiry');
function box_spring_send_inquiry() {
    $redirect = home_url('/?inquiry=error#contacts');
    $recipient = get_option('box_spring_inquiry_email', '');
    $valid = isset($_POST['inquiry_nonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['inquiry_nonce'])), 'box_spring_inquiry');
    $name = sanitize_text_field(wp_unslash($_POST['inquiry_name'] ?? ''));
    $phone = sanitize_text_field(wp_unslash($_POST['inquiry_phone'] ?? ''));
    $message = sanitize_textarea_field(wp_unslash($_POST['inquiry_message'] ?? ''));
    $key = 'box_spring_rate_'.hash_hmac('sha256', $_SERVER['REMOTE_ADDR'] ?? '', wp_salt());
    if ($valid && is_email($recipient) && get_option('box_spring_privacy_url') && !empty($_POST['consent']) && empty($_POST['website']) && $name && $phone && $message && strlen($name)<=500 && strlen($phone)<=200 && strlen($message)<=16000 && !get_transient($key)) {
        set_transient($key, 1, 60);
        $sent = wp_mail($recipient, 'Заявка на комплектацию Box Spring', 'Имя: '.$name."\nТелефон: ".$phone."\n\n".$message);
        if ($sent) { $redirect = home_url('/?inquiry=sent#contacts'); }
    }
    wp_safe_redirect($redirect);
    exit;
}
