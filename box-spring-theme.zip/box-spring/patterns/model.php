<?php
/**
 * Title: Карточка модели кровати
 * Slug: box-spring/model
 * Categories: featured
 */
?>
<!-- wp:group {"className":"model-card","layout":{"type":"default"}} --><div class="wp-block-group model-card"><!-- wp:heading {"level":3} --><h3 class="wp-block-heading">Новая модель кровати</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Добавьте фотографию через блок «Изображение». Укажите название, описание и характеристики модели.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p><a href="#contacts">Обсудить исполнение →</a></p><!-- /wp:paragraph --></div><!-- /wp:group -->