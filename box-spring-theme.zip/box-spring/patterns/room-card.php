<?php
/**
 * Title: Карточка мебели для номера
 * Slug: box-spring/room-card
 * Categories: featured
 */
?>
<!-- wp:group {"className":"model-card","layout":{"type":"default"}} --><div class="wp-block-group model-card"><!-- wp:heading {"level":3} --><h3 class="wp-block-heading">Название мебели</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Добавьте фотографию и описание изделия. Эта группа копируется целиком.</p><!-- /wp:paragraph --></div><!-- /wp:group -->