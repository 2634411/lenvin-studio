<?php
/**
 * Title: Карточка услуги
 * Slug: box-spring/service
 * Categories: featured
 */
?>
<!-- wp:group {"className":"service-card","layout":{"type":"default"}} --><div class="wp-block-group service-card"><!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":""} --><figure class="wp-block-image size-full "><img src="__ASSET__/assembly.jpg" alt="Фото услуги"/></figure><!-- /wp:image --><!-- wp:paragraph {"className":"service-number"} --><p class="service-number">05</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3 class="wp-block-heading">Новая услуга</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Добавьте описание услуги.</p><!-- /wp:paragraph --></div><!-- /wp:group -->