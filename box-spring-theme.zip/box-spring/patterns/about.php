<?php
/**
 * Title: Информационный блок о компании
 * Slug: box-spring/about
 * Categories: featured
 */
?>
<!-- wp:group {"className":"","layout":{"type":"default"}} --><div class="wp-block-group "><!-- wp:heading {"level":3} --><h3 class="wp-block-heading">О компании</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Добавьте информацию о производстве, опыте или условиях работы.</p><!-- /wp:paragraph --></div><!-- /wp:group -->