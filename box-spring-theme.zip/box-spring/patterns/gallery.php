<?php
/**
 * Title: Фотогалерея с переключением
 * Slug: box-spring/gallery
 * Categories: featured
 */
?>
<!-- wp:group {"className":"bs-carousel","layout":{"type":"default"}} --><div class="wp-block-group bs-carousel"><!-- wp:gallery {"columns":1,"imageCrop":false,"className":"bs-slides"} --><figure class="wp-block-gallery has-nested-images columns-1 bs-slides"><!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":""} --><figure class="wp-block-image size-full "><img src="__ASSET__/wood.jpg" alt="Фото изделия"/></figure><!-- /wp:image --><!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":""} --><figure class="wp-block-image size-full "><img src="__ASSET__/wood-front.jpg" alt="Дополнительное фото"/></figure><!-- /wp:image --></figure><!-- /wp:gallery --></div><!-- /wp:group -->